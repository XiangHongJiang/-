//
//  XHDDOnlineFunPlayUrlModel.m
//  DDOnline
//
//  Created by qianfeng on 16/3/10.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineFunPlayUrlModel.h"

@implementation XHDDOnlineFunPlayUrlModel


+ (NSDictionary *)objectClassInArray{
    return @{@"durl" : [PlayDurl class]};
}
@end
@implementation PlayDurl

@end


