//
//  XHDDOnlineRecommendCategorysCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/8.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineFunPlayModel.h"

@interface XHDDOnlineRecommendCategorysCell : UITableViewCell
/**
 *  recommendCategorysModel
 */
@property (nonatomic, strong) NSArray *recommendCategory;
@end
