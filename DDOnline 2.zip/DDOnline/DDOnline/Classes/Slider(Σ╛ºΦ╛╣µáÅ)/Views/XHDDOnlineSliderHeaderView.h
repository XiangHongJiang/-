//
//  XHDDOnlineSliderHeaderView.h
//  DDOnline
//
//  Created by qianfeng on 16/3/13.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XHDDOnlineSliderHeaderView : UIView

@end
