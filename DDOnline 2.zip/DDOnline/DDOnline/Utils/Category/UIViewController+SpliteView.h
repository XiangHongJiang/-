//
//  UIViewController+SpliteView.h
//  UIday18-网络数据请求
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 JXH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (SpliteView)

- (void)spliteView;

@end
