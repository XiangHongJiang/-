//
//  XHDDOnlineLastestMessageModel.m
//  DDOnline
//
//  Created by qianfeng on 16/3/22.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineLastestMessageModel.h"
#import "NSObject+Extension.h"

@implementation XHDDOnlineLastestMessageModel
//+ (instancetype)lasetstMessagModelWithDict:(NSDictionary *)dict{
//
//    return [self objectWithDict:dict];
//}
@end
