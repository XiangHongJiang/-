//
//  XHDDOnlineFunPlayDetailModel.m
//  DDOnline
//
//  Created by qianfeng on 16/3/9.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineFunPlayDetailModel.h"

@implementation XHDDOnlineFunPlayDetailModel

@end
@implementation FunPlayDetailResult

+ (NSDictionary *)objectClassInArray{
    return @{@"actor" : [Actor class], @"episodes" : [Episodes class], @"tags" : [Tags class]};
}

@end


@implementation User_Season

@end


@implementation Actor

@end


@implementation Episodes

@end


@implementation Up

@end


@implementation Tags

@end


