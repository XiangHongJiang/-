//
//  XHDDOnlineRecommendCategoryDetailCell.h
//  UIday16-04CollectionView3D
//
//  Created by qianfeng on 16/3/8.
//  Copyright (c) 2016年 JXH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineFunPlayModel.h"

@interface XHDDOnlineRecommendCategoryDetailCell : UICollectionViewCell
/**
 *  recommendCategoryDetailModel
 */
@property (nonatomic, strong) RecommendCategoryModel *categoryDetailModel;

@end
