//
//  XHDDOnlineJokeBaseCell.m
//  DDOnline
//
//  Created by qianfeng on 16/3/14.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineJokeBaseCell.h"

@implementation XHDDOnlineJokeBaseCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
