//
//  XHDDOnlineJokeDetailCommentsCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/23.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineJokeCommentsModel.h"

@interface XHDDOnlineJokeDetailCommentsCell : UITableViewCell
/**
 *  baseModel
 */
@property (nonatomic, strong) Comments_Data *commentsModel;

@end
