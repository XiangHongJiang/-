//
//  XHDDOnlineMainController.h
//  DDOnline
//
//  Created by qianfeng on 16/3/5.
//  Copyright © 2016年 JXHDev. All rights reserved.
//
/**
 主视图控制器，管理着tabBar
 */
#import <UIKit/UIKit.h>

@interface XHDDOnlineMainController : UIViewController

@end
