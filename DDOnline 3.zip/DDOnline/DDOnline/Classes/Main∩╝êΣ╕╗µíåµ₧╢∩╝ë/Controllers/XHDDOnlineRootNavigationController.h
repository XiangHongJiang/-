//
//  XHDDOnlineRootNavigationController.h
//  DDOnline
//
//  Created by qianfeng on 16/3/5.
//  Copyright © 2016年 JXHDev. All rights reserved.
//
/**
 继承自NavigationController，用于权限控制，管理视图推出
 */
#import <UIKit/UIKit.h>

@interface XHDDOnlineRootNavigationController : UINavigationController

@end
