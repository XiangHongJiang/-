//
//  XHDDOnlineLiveModel.h
//  DDOnline
//
//  Created by qianfeng on 16/3/7.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XHDDOnlineLiveModel : NSObject

@end
