//
//  XHDDOnlineLiveModel.m
//  DDOnline
//
//  Created by qianfeng on 16/3/7.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineLiveModel.h"

@implementation XHDDOnlineLiveModel

@end
