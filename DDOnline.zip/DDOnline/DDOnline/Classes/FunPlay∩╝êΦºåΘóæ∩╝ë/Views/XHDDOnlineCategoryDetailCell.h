//
//  XHDDOnlineCategoryDetailCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/8.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineFunPlayModel.h"

@interface XHDDOnlineCategoryDetailCell : UICollectionViewCell
/** *  model */
@property (nonatomic, strong) DeepList *model;
@end
