//
//  XHDDOnlineLatestUpdateCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/7.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineFunPlayModel.h"

@interface XHDDOnlineLatestUpdateCell : UICollectionViewCell
/** *  latestModel */
@property (nonatomic, strong) LatestList *latestModel;
@end
