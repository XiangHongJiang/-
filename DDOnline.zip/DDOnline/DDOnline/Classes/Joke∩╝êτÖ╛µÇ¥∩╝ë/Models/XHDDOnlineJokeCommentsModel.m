//
//  XHDDOnlineJokeCommentsModel.m
//  DDOnline
//
//  Created by qianfeng on 16/3/23.
//  Copyright © 2016年 JXHDev. All rights reserved.
//

#import "XHDDOnlineJokeCommentsModel.h"

@implementation XHDDOnlineJokeCommentsModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [Comments_Data class]};
}
@end
@implementation Comments_Data

@end


@implementation Comments_User

@end


