//
//  XHDDOnlineRootTabBarController.h
//  DDOnline
//
//  Created by qianfeng on 16/3/5.
//  Copyright © 2016年 JXHDev. All rights reserved.
//
/**
 继承自UITabBarController，用于添加管理的子控制器，管理兄弟视图的切换
 */
#import <UIKit/UIKit.h>

@interface XHDDOnlineRootTabBarController : UITabBarController

@end
