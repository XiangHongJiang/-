//
//  XHTextField.h
//  jianzhi
//
//  Created by qianfeng on 16/2/20.
//  Copyright © 2016年 JXH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XHTextField : UITextField

@end
