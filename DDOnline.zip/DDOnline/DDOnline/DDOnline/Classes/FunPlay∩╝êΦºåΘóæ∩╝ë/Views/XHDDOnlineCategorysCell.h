//
//  XHDDOnlineCategorysCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/7.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineFunPlayModel.h"

@interface XHDDOnlineCategorysCell : UITableViewCell
/** *  cotegoryModel */
@property (nonatomic, strong) CategoriesModel *categoryModel;
@end
