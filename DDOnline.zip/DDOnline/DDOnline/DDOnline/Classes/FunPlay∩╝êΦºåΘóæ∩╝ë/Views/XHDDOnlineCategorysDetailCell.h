//
//  XHDDOnlineCategorysDetailCell.h
//  DDOnline
//
//  Created by qianfeng on 16/3/10.
//  Copyright (c) 2016年 JXHDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHDDOnlineCategoryDetailModel.h"

@interface XHDDOnlineCategorysDetailCell : UITableViewCell
/**
 *  CategoryDetailResult
 */
@property (nonatomic, strong) CategoryDetailResult *detailModel;

@end
