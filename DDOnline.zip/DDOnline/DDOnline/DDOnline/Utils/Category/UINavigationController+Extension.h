//
//  UINavigationController+Extension.h
//  SinaWeiBo-Foundation
//
//  Created by qianfeng on 16/1/27.
//  Copyright (c) 2016年 JXH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (Extension)
-(void)aop_pushViewController:(UIViewController *)viewController animated:(BOOL)animated;
@end
